package id.sandrica.cathouse;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.*;
import android.widget.*;

public class MainActivity extends Activity {
    private static final int FILE_REQUEST = 1001;
    private static final String URL = "https://script.google.com/macros/s/AKfycbxPP67lqxMcDx1Fif2Jd25AFzQGpHQtcRC4m_4pOeRzv2PC3z3kF-JgSTTkeFrKsl0/exec";
    private WebView webView;
    private View splash;
    private ValueCallback<Uri[]> fileCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) { hideSplash(); }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) hideSplash();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme));
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try { startActivityForResult(Intent.createChooser(intent, "Pilih berkas"), FILE_REQUEST); return true; }
                catch (Exception e) { fileCallback = null; return false; }
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        splash = makeSplash();
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        webView.loadUrl(URL);
    }

    private View makeSplash() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.rgb(255,247,239));
        LinearLayout box = new LinearLayout(this);
        box.setGravity(Gravity.CENTER);
        box.setOrientation(LinearLayout.VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.sandrica_logo);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(220,220);
        lp.bottomMargin = 20;
        box.addView(logo, lp);
        TextView title = new TextView(this);
        title.setText("SANDRICA CAT HOUSE");
        title.setTextColor(Color.rgb(91,47,37));
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        box.addView(title);
        TextView sub = new TextView(this);
        sub.setText("PACAK & GROOMING");
        sub.setTextColor(Color.rgb(177,104,72));
        sub.setTextSize(14);
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2,-2);
        sp.topMargin = 8;
        box.addView(sub, sp);
        frame.addView(box, new FrameLayout.LayoutParams(-1,-1));
        return frame;
    }
    private void hideSplash() {
        if (splash != null) {
            View old = splash;
            splash = null;
            old.animate().alpha(0f).setDuration(250).withEndAction(() -> {
                if (old.getParent() instanceof ViewGroup) ((ViewGroup)old.getParent()).removeView(old);
            }).start();
        }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == FILE_REQUEST && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i=0;i<n;i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) results = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
