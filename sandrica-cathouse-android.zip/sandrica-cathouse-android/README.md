# Sandrica Cat House Android WebView

Membuka halaman Google Apps Script Sandrica Cathouse Pacak & Grooming.

Fitur:
- WebView tanpa address bar
- JavaScript dan DOM Storage
- Pemilih file untuk formulir web yang meminta unggahan
- Ikon aplikasi Android adaptif (ilustrasi awal)
- Splash screen bermerek

Unggah ZIP bernama `sandrica-cathouse-android.zip` ke root repository. Tambahkan workflow `build-apk.yml` ke `.github/workflows/`, lalu jalankan GitHub Actions. Logo di proyek ini adalah ilustrasi awal; ganti dengan logo resmi jika tersedia.
